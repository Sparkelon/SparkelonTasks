package stepDefinations;

import java.io.FileInputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import jxl.Sheet;
import jxl.Workbook;

public class NSTrainstepDefination {

	WebDriver driver;

@Given("^Open firefox and launch the NS Train App URL$")
public void open_firefox_and_launch_the_NS_Train_App_URL() throws Exception {
   
	System.setProperty("webdriver.gecko.driver", "C:\\Users\\admin\\Desktop\\KLM\\SeleniumNew\\drivers\\geckodriver.exe");
     driver = new FirefoxDriver();
    driver.get("https://www.ns.nl/en");
    driver.manage().window().maximize();
    Thread.sleep(8000);
    int size = driver.findElements(By.tagName("iframe")).size();
   System.out.println(size);
   driver.switchTo().frame(0);
	driver.findElement(By.xpath("/html/body/a[1]")).click();
	
	Thread.sleep(5000);
	 driver.switchTo().defaultContent();
	
	
	
}

@When("^Enter all the from and to field values$")
public void enter_all_the_from_and_to_field_values() throws Exception {
	String klmfile ="C:\\Users\\admin\\Desktop\\KLM\\NLApps.xls";
    FileInputStream fis  = new FileInputStream(klmfile );
    Workbook wb =Workbook.getWorkbook(fis);
     Sheet s=wb.getSheet("FromList");
   
     WebElement Fromlist =driver.findElement(By.id("location-input-FROM-POSITIONED"));
   		//xpath("//input[@id='location-input-FROM-POSITIONED']")).click();
     Fromlist.sendKeys(s.getCell(0,1).getContents());
     Fromlist.sendKeys(Keys.TAB);
   Thread.sleep(2000);
  WebElement Tolist = driver.findElement(By.id("location-input-TO-POSITIONED"));
  Tolist.sendKeys(s.getCell(1,1).getContents());
  Tolist.sendKeys(Keys.TAB); //button[contains(text(),'Upload')]
           Thread.sleep(2000);
}

@Then("^Verify all the details$")
public void verify_all_the_details() throws Exception {

	 driver.findElement(By.xpath("//div[@class='rppb-buttons rppb-buttons-right']//button[@type='submit']")).click();
	
}


	
	
	
	
	
}
