package stepDefinations;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import jxl.Sheet;
import jxl.Workbook;

public class stepDefination {

	public WebDriver driver;

@Given("Open firefox and start application")
public void open_firefox_and_start_application() throws Exception {
	System.setProperty("webdriver.gecko.driver", "C:\\Users\\Sparkelon\\Desktop\\Alekhya\\SeleniumNew\\drivers\\geckodriver.exe");
	driver =  new FirefoxDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	

    driver.get("https://www.klm.com/home/nl/en");

	  WebElement element = (new WebDriverWait(driver, 20))
              .until(ExpectedConditions.elementToBeClickable(By.xpath( "//*[text()=' Agree ']")));
	  element.click();

}

@When("Enter all the field values")
public void enter_all_the_field_values() throws Exception{
	
	String klmfile ="C:\\Users\\Sparkelon\\Desktop\\Alekhya\\Klmm.xls";
	FileInputStream fis = new FileInputStream(klmfile );
    Workbook wb =Workbook.getWorkbook(fis);
    Sheet s=wb.getSheet("FromList");
    int rowCount = s.getRows();
    int colcount =s.getColumns();
    Thread.sleep(4000);
    for( int i=1;i<3;i++){    
  //from text box
    		WebElement fromtext = driver.findElement(By.xpath("//div[@class='g-search-form--connections']//div[1]//label[1]//input[1]"));
    		 fromtext.sendKeys(s.getCell(0,i).getContents());
            Actions action = new Actions(driver);
     
            action.moveToElement(fromtext).build().perform();
            fromtext.sendKeys(Keys.DOWN);
            fromtext.sendKeys(Keys.RETURN);
            Thread.sleep(3000);
   //to text box
            WebElement totext = driver.findElement(By.xpath("//div[@class='g-search-form--connections']//div[1]//label[2]//input[1]"));
            totext.sendKeys(s.getCell(1,i).getContents());
           // Actions action1 = new Actions(driver);
            action.moveToElement(totext).build().perform();
            totext.sendKeys(Keys.DOWN);
            totext.sendKeys(Keys.RETURN);
          
           // driver.findElement(By.linkText("Eindhoven - Eindhoven Airport (EIN), Netherlands")).click();
    		//"//div[@class='g-search-form--connections']//div[1]//label[2]/input"));

    Thread.sleep(3000);
    //departure date
       driver.findElement(By.xpath("//*[@id='est-search-homepage']/div[2]/div[2]/form/div/div[1]/label[3]/input")).click();
       Thread.sleep(2000);
       driver.findElement(By.xpath(s.getCell(2,i).getContents())).click();
      // System.out.println(s.getCell(2,i).getContents());
 			       
       Thread.sleep(3000);
       
       //passengers
        driver.findElement(By.xpath("//span[contains(text(),'Passengers')]")).click();
        
        driver.findElement(By.xpath("//div[@class='selectorView']//div[3]//div[1]//button[2]")).click();
        		driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
       Thread.sleep(3000);
       //travel class dropdown
       driver.findElement(By.xpath("//select[@class='g-search-form--input g-forms-selectbox']")).click();
        Thread.sleep(2000);
       // driver.findElement(By.xpath("//option[@value='ECONOMY']")).click();
        driver.findElement(By.xpath(s.getCell(3,i).getContents())).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@class='g-search-form--footer g-clear']//span")).click();
        Thread.sleep(5000);
        driver.get("https://www.klm.com/home/nl/en");
    }
}

@Then("User should be able to view offers")
public void user_should_be_able_to_view_offers() throws Exception{
	System.out.println("user can able to navitage offerpage");
	
}
	
	
}
