package cucumberOptions;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/features",glue= {"stepDefinations"})

/*feature file -vl identify mapping stepDefinition ..
 * to run specific feature
features=src/test/java/features/login.feature

*/

public class TestRunner {

	
	
	
}
